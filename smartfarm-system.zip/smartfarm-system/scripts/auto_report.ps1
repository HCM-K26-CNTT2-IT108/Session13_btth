# AUDIT: xac nhan da tham dinh script, khong co lenh xoa hang loat
# Chay tu thu muc scripts: .\auto_report.ps1

$log = "..\data\log-he-thong.log"
$out = "..\backup\bao-cao-su-co.txt"

# Tieu de bao cao (ghi moi file)
Write-Output "BAO CAO SU CO SMARTFARM" > $out
Write-Output "Ngay gio: $(Get-Date)" >> $out
Write-Output "------------------------------" >> $out

# Loc dong CRITICAL hoac ERROR, chen noi vao bao cao
Get-Content $log | Select-String "CRITICAL|ERROR" >> $out

# Dem so dong loi bang pipeline
Write-Output "------------------------------" >> $out
Write-Output "TONG SO SU CO:" >> $out
Get-Content $log | Select-String "CRITICAL|ERROR" | Measure-Object | Select-Object -ExpandProperty Count >> $out
